import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class saveUMI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//we are reading in a file one line at a time
		if(args.length < 1)
		{
			System.err.println("Usage: saveUMI fastq1 fastq2 fastq3 ...");
			System.err.println("Grabs and inserts the first 5 bases of the read into its name but does not delete from seq.\n"
					+ "Generates _UMI.fastq as output for each file.");
			System.exit(1);
		}
		/**
		 * 				System.out.println("File\t"+str);
				System.out.println("Total reads\t"+totalReads);
				System.out.println("Qual!=Seq\t"+trimmed_diffLengths);
				System.out.println("Containing bad qual reads (trimmed)\t"+trimmed_bad_qual);
				System.out.println("Containing TTTTTTTTs\t"+trimmed_polyA);
				System.out.println("Too short after trimming bases\t"+trimmed_tooShort);
				System.out.println("Bad UMI quality detected (trimmed)\t"+trimmed_badUMI);
				System.out.println("Too many As left over after G trimming\t"+trimmed_tooManyAs);
		 */
		System.out.println("Name,Total Reads,Qual!=Seq,Has bad qual reads,has TTTTs,Too short after trimming,Bad UMI,No 3G,Too many As left,0 Gs,1 G,2 Gs,3 Gs,4 Gs,5 Gs,6 Gs,7 Gs,8 Gs,9 Gs");
		for(String str: args)
		{
			try {
				Scanner s = new Scanner(new File(str));
				PrintWriter pw = new PrintWriter(str.substring(0, str.indexOf(".fastq"))+"_UMI.fastq");
				int lines = 0;
				StringBuilder sb = new StringBuilder(1024*1024*100);
				int trimmed_diffLengths = 0;
				int trimmed_bad_qual =0;
				int trimmed_polyA = 0;
				int trimmed_tooShort = 0;
				int trimmed_badUMI = 0;
				int trimmed_no3G = 0;
				int[] gs = new int[10];
				int trimmed_tooManyAs = 0;
				int totalReads = 0;
				while(s.hasNextLine())
				{
					boolean keep = true;
					totalReads++;
					if(lines++ % 100000 == 0)
					{
						pw.print(sb.toString());
						sb = new StringBuilder(1024*1024*100);
						System.err.println("Processed "+(lines)+" reads in file "+str+"...");
					}

					s.nextLine();
					String seq = s.nextLine();
					String plus = s.nextLine(); // + string
					String qual = s.nextLine();
					if(seq.length() != qual.length())
					{
						trimmed_diffLengths++;
						keep = false;
					}
					//trim "POOR QUALITY" reads from the 3' end
					boolean hadAbadQual = false;
					while (qual.length() > 0)
					{
						char q = qual.charAt(qual.length()-1);
						if(q <= 'B')
						{
							hadAbadQual = true;
							qual= qual.substring(0,qual.length()-1);
							seq = seq.substring(0,seq.length()-1);
						}		
						else break;
					}
					if(hadAbadQual)
						trimmed_bad_qual++;
					//Lets trim polyA from the 3' end
					boolean trimmedSomeTs = false;
					while (seq.length() > 0)
					{
						char T = seq.charAt(seq.length()-1);
						
						if(T == 'T')
						{
							trimmedSomeTs=true;
							qual= qual.substring(0,qual.length()-1);
							seq = seq.substring(0,seq.length()-1);
						}
						else break;

					}
					if(trimmedSomeTs)						
						trimmed_polyA++;
					if(seq.length() < 25)
					{
						trimmed_tooShort++;
						keep =  false;
					}
					//extract UMI
					String UMI = seq.substring(0,5);
					String UMIqual = qual.substring(0,5);
					boolean badUMI = false;
					for(char c: UMIqual.toCharArray())
					{
						if( c < 'Q')
						{
							badUMI = true;
							break;
						}
					}
					if(badUMI)
					{
						trimmed_badUMI++;
						keep = false;
					}
					//trimming the UMI
					seq = seq.substring(5);
					qual = qual.substring(5);
					//lets trim GGGs (up to a maximum of 9 as per the paper methods)
					int gcount = 0;
					while(seq.startsWith("G") && gcount <3)
					{
						seq = seq.substring(1);
						qual = qual.substring(1);
						gcount++;
					}
					gs[gcount]++;
					if(gcount != 3)
					{
						trimmed_no3G++;
						keep = false;
					}
					int countA = 0;
					for(int i = 0; i < seq.length(); i++)
						if(seq.charAt(i) == 'A')
							countA++;
					if(seq.length()-countA < 6)
					{
						trimmed_tooManyAs++;
						keep = false;
					}
					if( keep)
					{
						sb.append('@'); sb.append(UMI);
						//sb.append(line.substring(1));
						sb.append(System.lineSeparator());
						sb.append(seq);sb.append(System.lineSeparator());
						sb.append(plus);sb.append(System.lineSeparator());
						sb.append(qual);sb.append(System.lineSeparator());
					}
				}
				pw.print(sb.toString());
				System.out.print(str);
				System.out.print(","+totalReads);
				System.out.print(","+trimmed_diffLengths);
				System.out.print(","+trimmed_bad_qual);
				System.out.print(","+trimmed_polyA);
				System.out.print(","+trimmed_tooShort);
				System.out.print(","+trimmed_badUMI);
				System.out.print(","+trimmed_no3G);
				System.out.print(","+trimmed_tooManyAs);
				for(int i = 0; i < gs.length; i++)
					System.out.print(","+gs[i]);
				System.out.println();
				s.close();
				pw.close();System.err.println("DONE! Processed "+totalReads);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
