
/**
 * Imposes the filter function
 * @author Maxim Shokhirev (C) 2015
 *
 */
public interface Filterable {

	public boolean filter(double stringency);
}
