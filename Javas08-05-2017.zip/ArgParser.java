import java.util.HashMap;
import java.util.LinkedList;

/**
 * Class designed for parsing arguments in a consistent manner. Register args, process a list of args, then ask for each arg in turn.
 * @author Maxim Shokhirev (C) 2015
 *
 */
public class ArgParser {
	private HashMap<String,String> args = new HashMap<String,String>();
	private LinkedList<String> list = new LinkedList<String>();
	private String description = "";
	private LinkedList<String> descriptions = new LinkedList<String>();
	
	public ArgParser(String description)
	{
		this.description = description;
	}
	
	public void registerArg(String name, String defaultValue, String description){
		args.put(name, defaultValue);
		descriptions.add("-"+name+"\t"+description+" (Default="+defaultValue+")");
	}
	
	
	public void printUsage()
	{
		System.err.println(description);
		System.err.println("\nOptions:");
		for(String str: descriptions)
		{
			System.err.println(str);
		}
		System.exit(1);
	}
	
	public void parseArgs(String[] args)
	{
		for(int i = 0; i < args.length; i++)
		{
			try{
			if(args[i].startsWith("-"))
			{
				String name = args[i].substring(1);

				if(i < args.length-1 && !args[i+1].startsWith("-"))
				{
					String value = args[i+1];
					i++;
					this.args.put(name,value);
				}
				else
					this.args.put(name,"true");
			}
			else
				list.add(args[i]);
			}catch(Exception e)
			{
				System.err.println("Error parsing: "+args[i]);
				printUsage();
			}
		}	
	}
	
	public String get(String key)
	{
		if(args.get(key)!= null)
			return args.get(key);
		return null;
	}
	
	public int getAsInt(String key)
	{
		if(args.get(key)!= null)
			return Integer.parseInt(args.get(key));
		return 0;
	}
	
	public double getAsDouble(String key)
	{
		if(args.get(key)!= null)
			return Double.parseDouble(args.get(key));
		return 0.0;
	}
	
	public boolean getAsBoolean(String key)
	{
		if(args.get(key)!= null)
			return Boolean.parseBoolean(args.get(key));
		return false;
	}
	
	public LinkedList<String> getList()
	{
		return list;
	}
	
	/**
	 * Prints values for all args: arg->value
	 * @return
	 */
	public LinkedList<String> getAllArgs()
	{
		LinkedList<String> result = new LinkedList<String>();
		for(String key: args.keySet())
		{
			result.add(key+"->"+args.get(key));
		}
		return result;
	}

}
