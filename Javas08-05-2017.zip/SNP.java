
public class SNP {

	char orig,mut;
	int pos;
	
	public SNP(int pos, char orig, char mut)
	{
		this.pos = pos; this.orig = orig; this.mut = mut;
	}
}
