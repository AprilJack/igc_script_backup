import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;


public class SuperScanner {

	BufferedReader s = null;
	
	public SuperScanner(String file)
	{
		try{
			InputStream fileStream = new FileInputStream(file);
			if(file.endsWith(".gz"))
				s = new BufferedReader(new InputStreamReader(new GZIPInputStream(fileStream)));
			else
				s = new BufferedReader(new InputStreamReader(fileStream));
		}catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void close()
	{
		try {
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean hasMore()
	{
		try {
			return s.ready();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public String getLine()
	{
		try {
			return s.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
